package Entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
public class Entity_koneksiDB {
    public static Connection con=null;
    public static Statement stat=null;
    public ResultSet res=null;

public static Connection GetConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/bukalapak1","root","");
            stat=con.createStatement();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            System.exit(2);
        }
        return con;
}
}
