/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author rahmi
 */
public class Entity_level {
    int id_level;
    String level;
    
    public void setID_level(int id_level)
    {
        this.id_level = id_level;
    }
  
    public void setLevel(String level)
    {
        this.level = level;
    }
    
    public int getID_level()
    {
        return id_level;
    }
    
    public String getLevel()
    {
        return level;
    }
    
}
