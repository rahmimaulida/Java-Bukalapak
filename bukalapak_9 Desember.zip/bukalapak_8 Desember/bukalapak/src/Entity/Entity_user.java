/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author rahmi
 */
public class Entity_user {
    
    String username,password,akses,email,kode;
   
    
    public void setKode(String kode)
    {
        this.kode = kode;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }
    
    
    public void setUsername(String username)
    {
        this.username = username;
    }
    
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    public void setAkses(String akses)
    {
        this.akses = akses;
    }
    
    public String getUsername()
    {
        return username;
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public String getAkses()
    {
        return akses;
    }
    
     public String getEmail()
    {
        return email;
    }
     
     public String getKode()
    {
        return kode;
    }
    
     
     
}
