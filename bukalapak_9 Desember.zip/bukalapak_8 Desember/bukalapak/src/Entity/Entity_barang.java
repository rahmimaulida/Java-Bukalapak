/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author rahmi
 */
public class Entity_barang {
    String kode_barang, nama_barang, jenis_barang, deskripsi,harga1, gambar , stok, harga;
    
    
    public void setKode_barang(String kode_barang)
    {
        this.kode_barang = kode_barang;
    }
    
    public void setNama_barang(String nama_barang)
    {
        this.nama_barang = nama_barang;
    }
    
    public void setJenis_barang(String jenis_barang)
    {
        this.jenis_barang = jenis_barang;
    }
    
    public void setDeskripsi(String deskripsi)
    {
        this.deskripsi = deskripsi;
    }
    public void setStok(String stok)
    {
        this.stok = stok;
    }
    public void setHarga(String harga)
    {
        this.harga = harga;
    }
    
    public void setHarga1(String harga1)
    {
        this.harga1 = harga1;
    }
    
    public void setGambar(String gambar)
    {
        this.gambar = gambar;
    }
    
    public String getKode_barang()
    {
        return kode_barang;
    }
    
    public String getNama_barang()
    {
        return nama_barang;
    }
    
    public String getJenis_barang()
    {
        return jenis_barang;
    }
    
    public String getDeskripsi()
    {
        return deskripsi;
    }
    public String getStok()
    {
        return stok;
    }
    
    public String getHarga()
    {
        return harga;
    }
    
    public String getHarga1(){
        return harga1;
    }
    
    public String getGambar()
    {
        return gambar;
    }
    
}
