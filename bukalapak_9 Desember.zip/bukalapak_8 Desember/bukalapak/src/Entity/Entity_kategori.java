/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author rahmi
 */
public class Entity_kategori {
    String jenis_barang;
    
    public void setJenis_barang(String jenis_barang)
    {
        this.jenis_barang = jenis_barang;
    }
    
    public String getJenis_barang()
    {
        return jenis_barang;
    }
    
}
