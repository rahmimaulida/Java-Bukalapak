/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;



/**
 *
 * @author Dx
 */
public class UserController {
   
     Connection con;
     Statement stat;
     ResultSet res;
  
     public UserController(){
         try{
               Class.forName("com.mysql.jdbc.Driver");
               con=DriverManager.getConnection("jdbc:mysql://localhost/bukalapak1","root","");
               stat=con.createStatement();
               System.out.println("Koneksi Berhasil");
               
         }catch (Exception error){
             JOptionPane.showMessageDialog(null, error);
         }
     }
     
     public void Login(Entity.Entity_user user){
         String sqlLogin="Select count(email) from user where email='"+user.getEmail()+
                         "' and password='"+user.getPassword()+"'";
         try{
             res=stat.executeQuery(sqlLogin);
             res.next();
             Integer loged=res.getInt(1);
             
             if(loged.equals(1)){
                 String sqlGrab="Select * from user where email='"+user.getEmail()+
                         "' and password='"+user.getPassword()+"'";
                 res=stat.executeQuery(sqlGrab);
                 res.next();
                 String grabAll=res.getString(1);
                 

              
              JOptionPane.showMessageDialog(null, "Hallo "+grabAll,"Login Sukses!",JOptionPane.INFORMATION_MESSAGE);
              //Rahmi tolong keluarkan halaman index.javanya (halaman utama disini kemudian dispose halaman login ini)
             }else if(loged.equals(0)){
              JOptionPane.showMessageDialog(null, "Akun Tidak Terdaftar","Error",JOptionPane.ERROR_MESSAGE);
}
             
         }catch (Exception error){
             JOptionPane.showMessageDialog(null, error);
         }
         
     }
     
       public void Daftar(Entity.Entity_user user){
         String sqlCek="Select count(email) from user where email='"+user.getEmail()+"'";
         try{
         res=stat.executeQuery(sqlCek);
         res.next();
         Integer terdaftar=res.getInt(1);
          if(terdaftar>0){
               JOptionPane.showMessageDialog(null, "Email telah terdaftar","Oops",JOptionPane.WARNING_MESSAGE);
          }else if(terdaftar.equals(0)){
               try{
               String daftar="insert into user values('"+user.getUsername()+"','"+user.getPassword()+"','Klien','"+user.getEmail()+"')";
               stat.executeUpdate(daftar);
               JOptionPane.showMessageDialog(null, "Akun "+user.getUsername()+" Sukses Terdaftar!","Sukses",JOptionPane.INFORMATION_MESSAGE);
              user.setKode("Sukses");
               }catch (Exception gagal){
                    JOptionPane.showMessageDialog(null, gagal);
                  
               }
          }
             
          }catch(Exception terdaftar){
               JOptionPane.showMessageDialog(null, terdaftar);
                 }
     }
       public void Lupa(Entity.Entity_user user){
           
           String sqlAll="select*from user where email='"+user.getEmail()+"'";
           try{
           res=stat.executeQuery(sqlAll);
           res.next();
           String password=res.getString(2);
           System.out.println(password);
            MD5 md=new MD5();
           String hasil=md.getMD5(password);
           String resetPass="Update user set reset_code='"+hasil+"' where email='"+user.getEmail()+"'";
            stat.executeUpdate(resetPass);
            JOptionPane.showMessageDialog(null, "Reset Password telah dikirim!","Sukses",JOptionPane.INFORMATION_MESSAGE);
           }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
           }
       }
     
}
