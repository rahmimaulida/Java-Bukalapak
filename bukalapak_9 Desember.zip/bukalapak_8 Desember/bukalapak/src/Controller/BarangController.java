/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import Entity.Entity_barang;
import Entity.Entity_kategori;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author rahmi
 */
public class BarangController {
     Connection con;
     Statement stat;
     ResultSet res;
 public  String kategori;
 
    
     public BarangController(){
         try{
               Class.forName("com.mysql.jdbc.Driver");
               con=DriverManager.getConnection("jdbc:mysql://localhost/bukalapak1","root","");
               stat=con.createStatement();
               System.out.println("Koneksi Berhasil");
               
         }catch (Exception error){
             JOptionPane.showMessageDialog(null, error);
         }
     }
    

     
     
     
 
     
     
     
     
     public  void getKategori(String kategori){
         this.kategori=kategori;
         Entity_kategori obj_kategory= new Entity_kategori();
         obj_kategory.setJenis_barang(kategori);
         
         System.out.println(obj_kategory.getJenis_barang());
         
     }
     
      public void getAllKategori(Entity.Entity_kategori jenis){
          
          
          
        
           String sqlAll="select * from kategori";
           try{
           res=stat.executeQuery(sqlAll);
           
               while (res.next()) {
                   String jenisBarang=res.getString(1); 
                   Entity_kategori katbarang=new Entity_kategori();
                   katbarang.setJenis_barang(jenisBarang);
                    System.out.println(katbarang.getJenis_barang());
                              
               }
           }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
           }
           
       }


    public void Insert(Entity_barang entBarang) {     
         try{
             String queryInsert="insert into barang (nama_barang, jenis_barang, deskripsi, stok, harga, gambar) values('"+entBarang.getNama_barang()+"','"+entBarang.getJenis_barang()+"','"+entBarang.getDeskripsi()+"','"+entBarang.getStok()+"','"+entBarang.getHarga1()+"','"+entBarang.getGambar()+"')";     
               stat.executeUpdate(queryInsert);
               
               JOptionPane.showMessageDialog(null, "Data Barang "+entBarang.getNama_barang()+" Sudah Tersimpan!","Sukses",JOptionPane.INFORMATION_MESSAGE);
              
               }catch (Exception gagal){
                    JOptionPane.showMessageDialog(null, gagal);
                  
               } 
        
    }
    
    public void Delete(Entity_barang entBarangDel){
        int konf = JOptionPane.showConfirmDialog(null, "Apakah anda yakin ingin menghapus data", "Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
        if(konf==0){
        String sql = "delete from barang where kode_barang='"+entBarangDel.getKode_barang()+"'";
        try {
            stat.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            /*jTextField2.setText("");
            jTextField1.requestFocus();
            datatabel();
            new formBeli().setVisible(true);
            this.setVisible(false); */
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Dihapus "+e);
        }
        }
    }
    
    public void Update(Entity_barang entBarangUpdate){
         String sql = "update barang set nama_barang='"+entBarangUpdate.getNama_barang()+"', jenis_barang='"+entBarangUpdate.getJenis_barang()+"', deskripsi='"+entBarangUpdate.getDeskripsi()+"', stok='"+entBarangUpdate.getStok()+"', harga='"+entBarangUpdate.getHarga1()+"', gambar='"+entBarangUpdate.getGambar()+"' where kode_barang='"+entBarangUpdate.getKode_barang()+"'";
        try {
            stat.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Diupdate");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Diupdate "+e);
        }
    }
    
    
         
         
}
