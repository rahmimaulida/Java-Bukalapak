/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author rahmi
 */
public class Koneksi {
    
   public class entity_koneksiDB {
    private Connection koneksi;
    public Connection koneksidb(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Koneksi ok");
        } catch (Exception e) {
            System.out.println("gagal");
        }
        String url="jdbc:mysql://localhost/bukalapak1";
        try {
            koneksi= (Connection) DriverManager.getConnection(url, "root", "");
            System.out.println("berhasil koneksi ke database");
        } catch (SQLException e) {
            System.out.println("Gagal koneksi database "+e);
        }
        return koneksi;
    } 
   
    
}
    
    
}
